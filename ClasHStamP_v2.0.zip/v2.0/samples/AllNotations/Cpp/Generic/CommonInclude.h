﻿#pragma once
#include <iostream>
#include <cassert>
#include <string>
#include <vector>

using String = std::string;
using Bool = bool;
using boolean = bool;
#define null nullptr

int InputValue(char* pMsg);
void DisplayMsg(char* pMsg);
