package model;


public class BaseClass
{
    public void virtualFunc(
        int param0
    ){
    } /* BaseClass.virtualFunc */
    public  BaseClass(
    ){
    }                                                                                           
}
