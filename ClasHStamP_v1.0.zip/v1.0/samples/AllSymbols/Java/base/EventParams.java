package base;

public class EventParams {
    int nEventId;
}
